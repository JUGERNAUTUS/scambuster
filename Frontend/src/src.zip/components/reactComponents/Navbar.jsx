import React, { Component, useState, useEffect } from "react";
import Web3 from "web3";
import { useNavigate } from "react-router-dom";
import "../../App.css";

function Nav(props) {
  const navigate = useNavigate();

  useEffect(() => {
    props.ConnectWallet();
  }, []);

  return (
    <div>
      {props.walletModal()}
      <nav className="navbar is-black py-3" aria-label="main navigation">
        <div className="navbar-brand">
          <a className="custom-align" href="https://scambuster.quantlabs.technology/">
            <img
              src={"/sb_icon.png"}
              className="ml-4"
              style={{ height: "60px", width: "60px" }}
            ></img>
          </a>
          <div className="navbar-item ">
            <h1 className="title is-3 ml-5" style={{ color: "white" }}>
              <a
                className="remove-link-decor"
                href="https://scambuster.quantlabs.technology/"
              >
                Scambuster
              </a>
            </h1>
          </div>
        </div>

        <div className="navbar-menu is-active">
          <div className="navbar-start"></div>
          <div className="navbar-menu mt-2">
            <a
              className="navbar-item ml-6"
              style={{ color: "white", fontSize: "20px", background: "none" }}
              onClick={() => {
                console.log("saw click");
                if (props.account) {
                  navigate("/proposer");
                } else {
                  props.activateModal();
                  //alert("Please Connect You Wallet 2");
                }
              }}
            >
              Submit a Website
            </a>

            <a
              className="navbar-item"
              style={{ color: "white", fontSize: "20px", background: "none" }}
              onClick={() => {
                if (props.account) {
                  navigate("/validator");
                } else {
                  props.activateModal();
                  // alert("Please Connect You Wallet 3");
                }
              }}
            >
              Validate
            </a>

            <a
              className="navbar-item"
              style={{ color: "white", fontSize: "20px", background: "none" }}
              onClick={() => {
                navigate("/searcher");
                // if (props.appState.account) {
                //   navigate("/searcher");
                // } else {
                //   activateModal();
                //   // alert("Please Connect You Wallet");
                // }
              }}
            >
              Search
            </a>

            <a
              className="navbar-item"
              style={{ color: "white", fontSize: "20px", background: "none" }}
              onClick={() => {
                navigate("/aboutus");
                // if (props.appState.account) {
                //   navigate("/");
                // } else {
                //   //activateModal()
                //   alert("Please Connect You Wallet 1");
                // }
              }}
            >
              About Us
            </a>
          </div>

          <div className="navbar-end mr-5 mt-2">
            <a
              className="navbar-item"
              href={
                navigator.userAgent.indexOf("Chrome") > -1
                  ? "https://scambuster.quantlabs.technology/"
                  : navigator.userAgent.indexOf("Firefox") > -1
                  ? "https://addons.mozilla.org/en-US/firefox/addon/scambuster/"
                  : "https://scambuster.quantlabs.technology/"
              }
              target="_blank"
            >
              Install Extension
            </a>
          </div>
          {props.isWeb3 && props.account ? (
            <div className="navbar-end mr-5 mt-2">
              <a className="navbar-item ">
                {" "}
                Account Connected : {props.account.slice(0, 8)}...
              </a>
            </div>
          ) : (
            <div className="navbar-end mr-5 mt-2 custom-align">
              <a
                className="navbar-item button is-link"
                onClick={() => props.ConnectWallet()}
              >
                Connect Metamask Wallet
              </a>
            </div>
          )}
        </div>
      </nav>
    </div>
  );
}

export default Nav;
